// import { useState } from "react";
// import "./App.css"; // 👈 custom styles

// export default function App() {
//   const [messages, setMessages] = useState([
//     { role: "assistant", content: "Hello! How can I help you today?" },
//   ]);
//   const [input, setInput] = useState("");
//   const [isLoading, setIsLoading] = useState(false);

//   const handleSend = async () => {
//     if (!input.trim()) return;

//     const newMessage = { role: "user", content: input };
//     setMessages((prev) => [...prev, newMessage]);
//     setInput("");
//     setIsLoading(true);

//     try {
//       const res = await fetch("http://localhost:3000/chat", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ message: input }),
//       });

//       const data = await res.json();

//       // Typing effect
//       let reply = "";
//       const replyText = data.reply || "No response";
//       for (let i = 0; i < replyText.length; i++) {
//         reply += replyText[i];
//         setMessages((prev) => {
//           const copy = [...prev];
//           if (copy[copy.length - 1]?.role === "assistant") {
//             copy[copy.length - 1].content = reply;
//           } else {
//             copy.push({ role: "assistant", content: reply });
//           }
//           return copy;
//         });
//         await new Promise((r) => setTimeout(r, 20));
//       }
//     } catch (err) {
//       console.error(err);
//       setMessages((prev) => [
//         ...prev,
//         { role: "assistant", content: "⚠️ Error connecting to server." },
//       ]);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div className="chat-container">
//       {/* Chat messages */}
//       <div className="chat-messages">
//         {messages.map((msg, idx) => (
//           <div key={idx} className={`message ${msg.role}`}>
//             {msg.content}
//           </div>
//         ))}

//         {isLoading && (
//           <div className="message assistant loading">
//             <span></span>
//             <span></span>
//             <span></span>
//           </div>
//         )}
//       </div>

//       {/* Input bar */}
//       <div className="chat-input">
//         <input
//           type="text"
//           placeholder="Type your message..."
//           value={input}
//           onChange={(e) => setInput(e.target.value)}
//           onKeyDown={(e) => e.key === "Enter" && handleSend()}
//           disabled={isLoading}
//         />
//         <button onClick={handleSend} disabled={isLoading}>
//           Send
//         </button>
//       </div>
//     </div>
//   );
// }

//! stream-version
// App.jsx
/*
import { useEffect, useRef, useState } from "react";
import "./App.css";

export default function App() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hello! How can I help you today?" },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // ---- autoscroll refs/state ----
  const containerRef = useRef(null);
  const bottomRef = useRef(null);
  const autoScrollRef = useRef(true); // toggled off if user scrolls up

  // Keep autoscroll on only when user is near the bottom
  const handleScroll = () => {
    const el = containerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    autoScrollRef.current = distanceFromBottom < 120; // near bottom -> keep autoscroll
  };

  // Scroll to bottom whenever messages update (and user hasn't scrolled up)
  useEffect(() => {
    if (!bottomRef.current) return;
    if (!autoScrollRef.current) return;
    // use rAF to wait for DOM paint after React updates the message text
    requestAnimationFrame(() => {
      bottomRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    });
  }, [messages, isLoading]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setInput("");
    setIsLoading(true);

    // placeholder for assistant
    let assistantIndex = -1;
    setMessages((prev) => {
      assistantIndex = prev.length;
      return [...prev, { role: "assistant", content: "" }];
    });

    try {
      const res = await fetch("http://localhost:3000/chat-stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });

        setMessages((prev) => {
          const copy = [...prev];
          if (assistantIndex === -1) assistantIndex = copy.length - 1;
          copy[assistantIndex] = {
            ...copy[assistantIndex],
            content: (copy[assistantIndex].content || "") + chunk,
          };
          return copy;
        });
      }
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "⚠️ Error connecting to server." },
      ]);
    } finally {
      setIsLoading(false);
      // after finish, force one last scroll
      requestAnimationFrame(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
      });
    }
  };

  return (
    <div className="chat-container">
      <div
        className="chat-messages"
        ref={containerRef}
        onScroll={handleScroll}
      >
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>
            {msg.content}
          </div>
        ))}

        {isLoading && (
          <div className="message assistant loading">
            <span></span><span></span><span></span>
          </div>
        )}

     
        <div ref={bottomRef} />
      </div>


      <div className="chat-input">
        <input
          type="text"
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          disabled={isLoading}
        />
        <button onClick={handleSend} disabled={isLoading || !input.trim()}>
          Send
        </button>
      </div>
    </div>
  );
}
*/

// App.jsx
import { useEffect, useRef, useState } from "react";
import "./App.css";
import MarkdownRenderer from "./MarkdownRenderer";

export default function App() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hello! How can I help you today?" },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const containerRef = useRef(null);
  const bottomRef = useRef(null);
  const autoScrollRef = useRef(true);

  const handleScroll = () => {
    const el = containerRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    autoScrollRef.current = distance < 120;
  };

  useEffect(() => {
    if (autoScrollRef.current) {
      requestAnimationFrame(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
      });
    }
  }, [messages, isLoading]);

  // autosize
  const taRef = useRef(null);
  const autosize = () => {
    const el = taRef.current;
    if (!el) return;
    el.style.height = "0px";
    const max = 200; // px cap (about 8–10 lines depending on font)
    el.style.height = Math.min(el.scrollHeight, max) + "px";
  };
  useEffect(() => {
    autosize();
  }, [input]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    setMessages((p) => [...p, { role: "user", content: text }]);
    setInput("");
    setIsLoading(true);

    let assistantIndex = -1;
    setMessages((p) => {
      assistantIndex = p.length;
      return [...p, { role: "assistant", content: "" }];
    });

    try {
      const res = await fetch("http://localhost:3000/chat-stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });

        setMessages((prev) => {
          const copy = [...prev];
          if (assistantIndex === -1) assistantIndex = copy.length - 1;
          copy[assistantIndex] = {
            ...copy[assistantIndex],
            content: (copy[assistantIndex].content || "") + chunk,
          };
          return copy;
        });
      }
    } catch (e) {
      console.error(e);
      setMessages((p) => [
        ...p,
        { role: "assistant", content: "⚠️ Error connecting to server." },
      ]);
    } finally {
      setIsLoading(false);
      requestAnimationFrame(() => {
        bottomRef.current?.scrollIntoView({ behavior: "smooth" });
      });
    }
  };

  const onKeyDown = (e) => {
    // Enter -> send, Shift+Enter -> newline
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="chat-container">
      <div className="chat-messages" ref={containerRef} onScroll={handleScroll}>
        {messages.map((m, i) => (
          <div key={i} className={`message ${m.role}`}>
            <MarkdownRenderer content={m.content} />
          </div>
        ))}
        {isLoading && (
          <div className="message assistant loading">
            <span></span>
            <span></span>
            <span></span>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* <div className="chat-input">
        <input
          type="text"
          placeholder="Type your message…"
          value={input}
            onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          disabled={isLoading}
        />
        <button onClick={handleSend} disabled={isLoading || !input.trim()}>
          Send
        </button>
      </div> */}
      <div className="chat-input fancy">
        <textarea
          ref={taRef}
          className="chat-textarea"
          placeholder="Type your message… (Shift+Enter for new line)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          disabled={isLoading}
          rows={1}
        />
        <button
          className="send-btn"
          onClick={handleSend}
          disabled={isLoading || !input.trim()}
          aria-label="Send message"
          title="Send (Enter)"
        >
          ➤
        </button>
      </div>
    </div>
  );
}
